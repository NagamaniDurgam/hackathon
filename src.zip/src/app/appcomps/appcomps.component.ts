import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-appcomps',
  templateUrl: './appcomps.component.html',
  styleUrls: ['./appcomps.component.css']
})
export class AppcompsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
