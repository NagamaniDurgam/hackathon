import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manualclaim',
  templateUrl: './manualclaim.component.html',
  styleUrls: ['./manualclaim.component.css']
})
export class ManualclaimComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
