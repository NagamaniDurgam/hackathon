import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-smartclaim',
  templateUrl: './smartclaim.component.html',
  styleUrls: ['./smartclaim.component.css']
})
export class SmartclaimComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
